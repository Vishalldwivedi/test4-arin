def lambda_handler(event, context):
  return {
    'statusCode': 200, 
    'body': ' its been a long day hi hihi hihi hih   :)'
  }
